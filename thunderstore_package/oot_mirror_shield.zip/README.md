# OoT Mirror Shield for Majora's Mask in Zelda 64 Recompiled
This mod replaces the mirror shield with the OoT version. You can switch between the N64 and the GC/Wii/3DS designs, as well as change the border color with an RGB selector.

![Example](https://github.com/user-attachments/assets/739d65e4-1980-4760-af8e-4f4bdcc30b2c)

![Mod Menu](https://github.com/user-attachments/assets/cc38d445-490e-45f7-9b8f-1a82fd73aa3d)

# Planned updates:
* Replace GI model
* Replace UI textures